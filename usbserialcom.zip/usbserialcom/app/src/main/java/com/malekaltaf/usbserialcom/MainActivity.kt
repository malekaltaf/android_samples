package com.malekaltaf.usbserialcom

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.felhr.usbserial.UsbSerialDevice
import com.felhr.usbserial.UsbSerialInterface
import com.malekaltaf.usbserialcom.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var m_usbManager:UsbManager
    var m_device: UsbDevice? = null
    var m_serial: UsbSerialDevice? = null
    var m_connection: UsbDeviceConnection? = null

    val ACTION_USB_PERMISSION = "permission"

    var binding: ActivityMainBinding? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding!!.root)

        m_usbManager = getSystemService(Context.USB_SERVICE) as UsbManager

        val filter = IntentFilter()
        filter.addAction(ACTION_USB_PERMISSION)
        filter.addAction(UsbManager.ACTION_USB_ACCESSORY_ATTACHED)
        filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
        registerReceiver(broadcastReceiver,filter)

        binding?.on?.setOnClickListener {
            sendData( "1")
        }

        binding?.off?.setOnClickListener {
            sendData("2")
        }

        binding?.connect?.setOnClickListener {
            startUsbConnecting()
        }

        binding?.disconnect?.setOnClickListener {
            disconnect()
        }

    }

    private fun startUsbConnecting() {
        val usbDevices: HashMap<String,UsbDevice>? = m_usbManager.deviceList
        if(!usbDevices?.isEmpty()!!){
            var keep = true
            usbDevices.forEach{entry ->
                m_device = entry.value
                val deviceVendorId:Int? = m_device?.vendorId
                Log.i("Serial","vendorID : $deviceVendorId")
                Toast.makeText(applicationContext,"vendor id : $deviceVendorId",Toast.LENGTH_LONG).show()
                if (deviceVendorId == 8183) {
                    val intent: PendingIntent = PendingIntent.getBroadcast(this,0,Intent(ACTION_USB_PERMISSION),0)
                    m_usbManager.requestPermission(m_device, intent)
                    keep = false
                    Log.i("Serial","connection successful")
                    Toast.makeText(applicationContext,"Connection Successful",Toast.LENGTH_LONG).show()
                }else{
                    m_connection = null
                    m_device = null
                    Log.i("Serial","unable to connect")
                    Toast.makeText(applicationContext,"Unable to connect",Toast.LENGTH_LONG).show()
                }
                if(!keep){
                   return
                }
            }
        }else {
            Log.i("Serial","no usb device is connected")
        }
    }

    private fun sendData(input: String) {
        m_serial?.write(input.toByteArray())
        Log.i("Serial","Sending data :  ${input.toByteArray()}")
        Toast.makeText(applicationContext,"Sending data :  ${input.toByteArray()}",Toast.LENGTH_LONG).show()
    }

    private  fun disconnect() {
        m_serial?.close()
    }

    private  val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if(intent?.action!! == ACTION_USB_PERMISSION) {
                val granted: Boolean = intent.extras!!.getBoolean(UsbManager.EXTRA_PERMISSION_GRANTED)
                if (granted) {
                    m_connection = m_usbManager.openDevice(m_device)
                    m_serial = UsbSerialDevice.createUsbSerialDevice(m_device,m_connection)
                    if (m_serial != null){
                        if(m_serial!!.open()){
                            m_serial!!.setBaudRate(9600)
                            m_serial!!.setDataBits(UsbSerialInterface.DATA_BITS_8)
                            m_serial!!.setStopBits(UsbSerialInterface.STOP_BITS_1)
                            m_serial!!.setParity(UsbSerialInterface.PARITY_NONE)
                            m_serial!!.setFlowControl(UsbSerialInterface.FLOW_CONTROL_OFF)
                        }
                        else {
                            Log.i("Serial","port not open")
                            Toast.makeText(applicationContext,"Port Not Open",Toast.LENGTH_SHORT).show()
                        }
                    }else {
                        Log.i("Serial","port is null")
                        Toast.makeText(applicationContext,"Port is NULL",Toast.LENGTH_SHORT).show()
                    }
                }else{
                    Log.i("Serial","Permission is not granted")
                    Toast.makeText(applicationContext,"permission is not granted",Toast.LENGTH_SHORT).show()
                }
            } else if (intent.action == UsbManager.ACTION_USB_DEVICE_ATTACHED){
                startUsbConnecting()
            }
            else if(intent.action == UsbManager.ACTION_USB_DEVICE_DETACHED){
                disconnect()
            }
        }
    }

}