package com.vamacomm.myapplication

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.androidgamesdk.gametextinput.Listener
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textview:TextView
        textview = findViewById(R.id.textView)

//        val client = OkHttpClient()
//        val request = Request.Builder()
//            .url("https://192.168.150.1")
//            .build()
//
//        client.newCall(request).enqueue(object : Callback {
//            override fun onFailure(call: Call, e: IOException) {
//                // Handle failure
//                textview.text = "failed"
//            }
//
//            override fun onResponse(call: Call, response: Response) {
////                val body = response.body?.string()
//                // Handle response
//                textview.text = "success"
//            }
//        })


        



//            OLD CODE DATA
//            OLD CODE DATA
//            OLD CODE DATA

//
        val client = OkHttpClient()
//        val url = "https://publicobject.com/helloworld.txt"
        val url = "https://192.168.150.1:80/a"
        val request = Request.Builder().url(url).get().build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
                runOnUiThread { textview.setText("myNewText+$e") }
            }

            override fun onResponse(call: Call, response: Response) {
                if(response.isSuccessful) {
                    runOnUiThread { textview.setText("myNewText") }
                }
            }
        })


//            OLD CODE DATA
//            OLD CODE DATA
//            OLD CODE DATA
    }
}
