package com.vamacomm.speechtotext

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import com.robsonribeiroft.texttospeechexemple.TTS
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okio.IOException
import java.util.Locale
import java.util.Objects

class MainActivity : AppCompatActivity() {
    private val REQUEST_CODE_SPEECH_INPUT = 1
    lateinit var tv:TextView
    private var tts: TextToSpeech? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val mic:ImageView = findViewById(R.id.mic)
        val audio:ImageView = findViewById(R.id.audio)
        tv = findViewById(R.id.tv)


        mic.setOnClickListener {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            intent.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            intent.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE,
                Locale.getDefault()
            )
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Ask To Curio")
            try {
                startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT)
            } catch (e: Exception) {
                // on below line we are displaying error message in toast
                Toast.makeText(this@MainActivity, " " + e.message, Toast.LENGTH_SHORT).show()
            }
        }


        tv.addTextChangedListener {
            TTS(this@MainActivity, tv.text.toString(), true)
        }

        audio.setOnClickListener {
           // TTS(this@MainActivity, tv.text.toString(), true)

        }
    }


    private fun speakOut(message: String) {
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, null)
    }


    var postdata =""
    // on below line we are calling on activity result method.
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        // in this method we are checking request
        // code with our result code.
        if (requestCode == REQUEST_CODE_SPEECH_INPUT) {
            // on below line we are checking if result code is ok
            if (resultCode == RESULT_OK && data != null) {
                // in that case we are extracting the
                // data from our array list
                val res: ArrayList<String> = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS) as ArrayList<String>
                // on below line we are setting data
                // to our output text view.
                //tv.setText(Objects.requireNonNull(res)[0])
                Log.i("response",Objects.requireNonNull(res)[0])
                postdata = Objects.requireNonNull(res)[0]
                sendDataToServer(postdata)
            }
        }
    }

    private fun sendDataToServer(postdata: String) {
        //val url = "https://vamacomm.com/EC_Android/send.php?key_name=$postdata"
        val url = "https://d1cb-2402-8100-27c3-6ea8-5c61-6882-c87-90d0.ngrok-free.app/text/$postdata"
        val client = OkHttpClient()
        val request = Request.Builder()
//            .addHeader("","")
            .url(url).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
               // println(response.body!!.string())
                val restv = response.body!!.string()
//                Log.i("response",restv.toString())
                runOnUiThread { tv.text = restv.toString() }
            }
        })

    }
}
