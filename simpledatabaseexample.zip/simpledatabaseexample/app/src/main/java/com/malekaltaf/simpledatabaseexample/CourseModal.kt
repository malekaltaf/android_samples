package com.malekaltaf.simpledatabaseexample

class CourseModal     // constructor
    (// creating getter and setter methods
    // variables for our coursename,
    // description, tracks and duration, id.
    var courseName: String,
    string: Any,
    string1: Any,
    string2: Any
) {
    var id = 0

}