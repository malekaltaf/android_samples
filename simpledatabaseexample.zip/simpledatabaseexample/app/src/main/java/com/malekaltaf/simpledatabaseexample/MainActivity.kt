package com.malekaltaf.simpledatabaseexample

import android.R
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.*
import com.malekaltaf.simpledatabaseexample.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var dbHandler = DBHandler(this);

        binding.edittext.addTextChangedListener {
            if (binding.edittext.length() < 5){
                binding.Create.isEnabled = false
                binding.Delete.isEnabled = false
                binding.Update.isEnabled = false
                binding.edittext.error = "Entered Value Must Be More Than 5 Char"

            }else{
                binding.Create.isEnabled = true
                binding.Read.isEnabled = true
                binding.Delete.isEnabled = true
                binding.Update.isEnabled = true
            }
        }

        binding.Create.setOnClickListener {
            dbHandler.addNewCourse(binding.edittext.text.toString())
            Toast.makeText(this,"data inserted successfully",Toast.LENGTH_SHORT).show()
            binding.edittext.text = null
        }
        binding.Read.setOnClickListener {

            var courseModalArrayList: ArrayList<CourseModal?>?
            val coursesRV: RecyclerView
            // initializing our all variables.
            // initializing our all variables.
            courseModalArrayList = ArrayList()
            var dbHandler: DBHandler = DBHandler(this)

            // getting our course array
            // list from db handler class.

            // getting our course array
            // list from db handler class.
            val also = dbHandler.readCourses().also { courseModalArrayList }

            // on below line passing our array list to our adapter class.

            // on below line passing our array list to our adapter class.
            val courseRVAdapter: CourseRVAdapter = CourseRVAdapter(courseModalArrayList, this)
            coursesRV = binding.idRVCourses

            // setting layout manager for our recycler view.

            // setting layout manager for our recycler view.
            val linearLayoutManager =
                LinearLayoutManager(this, RecyclerView.VERTICAL, false)
            coursesRV.setLayoutManager(linearLayoutManager)

            // setting our adapter to recycler view.

            // setting our adapter to recycler view.
            coursesRV.setAdapter(courseRVAdapter)
        }
        binding.Update.setOnClickListener {

        }
        binding.Delete.setOnClickListener {

        }


    }
}