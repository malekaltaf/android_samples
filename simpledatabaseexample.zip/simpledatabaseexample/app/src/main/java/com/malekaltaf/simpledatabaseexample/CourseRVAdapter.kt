package com.malekaltaf.simpledatabaseexample

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlin.Int as Int1


class CourseRVAdapter     // constructor
    (// variable for our array list and context
    private val courseModalArrayList: ArrayList<CourseModal?>?, private val context: Context
) :
    RecyclerView.Adapter<CourseRVAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int1): ViewHolder {
        // on below line we are inflating our layout
        // file for our recycler view items.
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.course_rv_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int1) {
        // on below line we are setting data
        // to our views of recycler view item.
        val modal = courseModalArrayList?.get(position)
        if (modal != null) {
            holder.courseNameTV.text = modal.courseName
        }
    }

    override fun getItemCount(): kotlin.Int {
        // returning the size of our array list
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // creating variables for our text views.
        val courseNameTV: TextView

        init {
            // initializing our text views
            courseNameTV = itemView.findViewById(R.id.idTVCourseName)
        }
    }
}
