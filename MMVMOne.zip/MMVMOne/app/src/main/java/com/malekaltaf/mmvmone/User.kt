package com.malekaltaf.mmvmone

class User(var email: String, var password: String)