package com.malekaltaf.screentrasit

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        val button = findViewById<Button>(R.id.button2)
        button.setOnClickListener {
            finish()
            overridePendingTransition(android.R.anim.fade_out,android.R.anim.fade_out)
        }
    }
}