package com.malekaltaf.screentrasit

import android.app.ActivityOptions
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Window
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val button = findViewById<Button>(R.id.button)
        button.setOnClickListener {
//            val image = findViewById<ImageView>(R.id.imageView)
//            val animation = AnimationUtils.loadAnimation(applicationContext,R.anim.slide)
//            image.startAnimation(animation)
//            Intent(this,MainActivity2::class.java)
//            startActivity(intent)
            startActivity(Intent(this,MainActivity2::class.java))
            overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_in)


//            startActivity(Intent(this,MainActivity2::class.java),
//                ActivityOptions.makeSceneTransitionAnimation(this).toBundle())

        }
    }
}