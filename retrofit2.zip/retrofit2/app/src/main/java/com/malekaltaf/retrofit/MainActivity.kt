package com.malekaltaf.retrofit

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.malekaltaf.retrofit.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    var binding: ActivityMainBinding? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding!!.root)

        val queue = Volley.newRequestQueue(this)
        val url = "https://pokeapi.co/api/v2/generation/"

// Request a string response from the provided URL.
        val stringRequest = StringRequest(
            Request.Method.GET, url,
            { response ->
                // Display the first 500 characters of the response string.
                binding?.textView?.text = "Response is: ${response.substring(0, 500)}"
            },
            { binding?.textView?.text = "That didn't work!" })

// Add the request to the RequestQueue.
        queue.add(stringRequest)

    }
}