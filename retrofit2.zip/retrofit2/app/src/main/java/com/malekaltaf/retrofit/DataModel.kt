package com.malekaltaf.retrofit

class DataModel {
    private val name: String? = null
    fun getName(): String? {
        return name
    }
}