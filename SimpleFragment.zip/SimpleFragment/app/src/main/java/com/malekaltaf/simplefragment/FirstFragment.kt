package com.malekaltaf.simplefragment

import androidx.fragment.app.Fragment

class FirstFragment : Fragment(R.layout.fragment_first) {
}