package com.malekaltaf.simplefragment

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.FragmentManager
import com.malekaltaf.simplefragment.databinding.ActivityMainBinding
import com.malekaltaf.simplefragment.databinding.ActivityMainBindingImpl

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val firstFragment = FirstFragment()
        val secondFragment = SecondFragment()

        supportFragmentManager.beginTransaction().apply {
            replace(R.id.fragment,firstFragment)
            commit()
        }

        binding.fragment1.setOnClickListener {
            supportFragmentManager.beginTransaction().apply {
                replace(R.id.fragment,firstFragment)
                addToBackStack(null)
                commit()
            }
        }

        binding.fragment2.setOnClickListener {
            supportFragmentManager.beginTransaction().apply {
                replace(R.id.fragment,secondFragment)
                addToBackStack(null)
                commit()
            }
        }
    }
}