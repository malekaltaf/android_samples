package com.example.restapi

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException


class MainActivity : AppCompatActivity() {

    private val client = OkHttpClient()
    val textViewResult = findViewById<TextView>(R.id.textView2)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        getResults();
    }

    private fun getResults() {
        getApiService().postResponse(getRequestModel()).enqueue(object : Callback<ResponseBody?>() {
            fun onResponse(call: Call<ResponseBody?>?, response: Response<ResponseBody?>) {
                try {
                    Log.d("RetrofitBruh", response.body().string())
                    textViewResult.setText(response.body().string()) //setting text here
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }

            fun onFailure(call: Call<ResponseBody?>?, t: Throwable?) {}
        })
    }


    private fun getApiService(): ApiInterface? {
        val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl("http://w.x.y.z:1111/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        return retrofit.create(ApiInterface::class.java)
    }

    private fun getRequestModel(): RequestBody? {
        val json = """
            {
            "nam":"Alex",
            "namk":""
            }
            """.trimIndent()
        return RequestBody.create(MediaType.parse("application/json"), json)
    }

}
