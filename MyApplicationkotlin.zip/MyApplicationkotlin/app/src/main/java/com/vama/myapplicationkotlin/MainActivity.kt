@file:Suppress("DEPRECATION", "UNUSED_ANONYMOUS_PARAMETER")

package com.vama.myapplicationkotlin

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.*
import android.webkit.WebView
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.constraintlayout.widget.ConstraintLayout

class MainActivity : AppCompatActivity() {

    private val myWebUrl: String = "file:///android_asset/index.html"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val webView = findViewById<WebView>(R.id.webview)

//        val wedData: String =  "<html><body><h1>Hello, javaTPoint!</h1></body></html>"
//        val mimeType: String = "text/html"
//        val utfType: String = "UTF-8"
//        webView.loadData(wedData,mimeType,utfType)

        webView.loadUrl(myWebUrl)


//        webView.webViewClient = MyWebViewClient(this)
//        webView.loadUrl("https://www.javatpoint.com/")



//        val layout = findViewById<ConstraintLayout>(R.id.layout)
//
//        val button4 = Button(this)
//        button4.layoutParams = ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
//        button4.text = "Added Dynamically"
//        layout.addView(button4)
//        var textView = findViewById<TextView>(R.id.textView)
//        var editText = findViewById<EditText>(R.id.editText)
//        var button = findViewById<Button>(R.id.button)
//        button.setOnClickListener {
//            textView.text = editText.text.toString()
//           myToast.setGravity(Gravity.LEFT, 200, 200)
////            myToast.show()
////        }       val myToast = Toast.makeText(this, "toast message with gravity", Toast.LENGTH_SHORT)
//

        val layout = layoutInflater.inflate(R.layout.custom_toast,ConstraintLayout(this))

        val button1 = findViewById<Button>(R.id.button)
        button1.setOnClickListener{
            val myToast = Toast(applicationContext)
            myToast.duration = Toast.LENGTH_LONG
            myToast.setGravity(Gravity.CENTER_VERTICAL, 0, 0)
            myToast.view = layout//setting the view of custom toast layout
            myToast.show()
        }



        val button7 = findViewById<Button>(R.id.button7)
        button7.setOnClickListener {
            val popupMenu = PopupMenu(this,button7)
            popupMenu.menuInflater.inflate(R.menu.menu_main,popupMenu.menu)
            popupMenu.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.call ->
                        Toast.makeText(
                            this@MainActivity,
                            "You Clicked : " + item.title,
                            Toast.LENGTH_SHORT
                        ).show()
                    R.id.sms ->
                        Toast.makeText(
                            this@MainActivity,
                            "You Clicked : " + item.title,
                            Toast.LENGTH_SHORT
                        ).show()
                }
                true
            }
            popupMenu.show()
        }
        val button3 = findViewById<Button>(R.id.button3)
        val button4 = findViewById<Button>(R.id.button4)

        button3.setOnClickListener{
            intent = Intent(applicationContext, SecondActivity::class.java)
            startActivity(intent)
        }
        button4.setOnClickListener {
//            intent = Intent(android.provider.Settings.ACTION_SETTINGS)
//            startActivity(intent)
            intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse("https://www.javatpoint.com/")
            startActivity(intent)
        }

        val button2 = findViewById<Button>(R.id.button2)
        button2.setOnClickListener{
            intent = Intent(this,SecondActivity::class.java)
            intent.putExtra("id_value",1001)
            intent.putExtra("language_value","ENG")
            startActivity(intent)
        }

        val button6 = findViewById<Button>(R.id.button6)
        button6.setOnClickListener{
            startActivity(Intent(this,custom_listview::class.java))
        }



        val button5 = findViewById<Button>(R.id.button5)
        button5.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Delete File")
            builder.setMessage("Deleting file may be harm your system")
            builder.setIcon(android.R.drawable.ic_dialog_alert)
            builder.setPositiveButton("Yes"){dialogInterface, which ->
                Toast.makeText(applicationContext,"clicked yes",Toast.LENGTH_LONG).show()
            }
            builder.setNeutralButton("Cancel"){dialogInterface , which ->
                Toast.makeText(applicationContext,"clicked cancel\n operation cancel",Toast.LENGTH_LONG).show()
            }
            builder.setNegativeButton("No"){dialogInterface, which ->
                Toast.makeText(applicationContext,"clicked No",Toast.LENGTH_LONG).show()
            }
            val alertDialog: AlertDialog = builder.create()
            alertDialog.setCancelable(false)
            alertDialog.show()
        }

        val button8 = findViewById<Button>(R.id.button8)
        button8.setOnClickListener{
            startActivity(Intent(this,seekbar::class.java))
        }

        val button9 = findViewById<Button>(R.id.button9)
        button9.setOnClickListener {
            startActivity(Intent(this,framelayout1::class.java))
        }

        val button10 = findViewById<Button>(R.id.button10)
        button10.setOnClickListener {

        }




    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menu_main, menu)
        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle item selection
        return when (item.itemId) {
            R.id.call -> {
                Toast.makeText(this,"Callable",Toast.LENGTH_LONG).show()
                true
            }
            R.id.sms-> {
                Toast.makeText(this,"SMSable",Toast.LENGTH_LONG).show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

}

//class MyWebViewClient internal constructor(private val activity: Activity) : WebViewClient() {
//    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
//        val url: String = request?.url.toString()
//        view?.loadUrl(url)
//        return true
//    }
//}