package com.vamacomm.pdfviewer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.rajat.pdfviewer.PdfViewerActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val open_pdf = findViewById<Button>(R.id.open_pdf)
        open_pdf.setOnClickListener {
            startActivity(

                // Use 'launchPdfFromPath' if you want to use assets file (enable "fromAssets" flag) / internal directory

                PdfViewerActivity.launchPdfFromUrl(           //PdfViewerActivity.Companion.launchPdfFromUrl(..   :: incase of JAVA
                    this,
                    "https://www.africau.edu/images/default/sample.pdf",                                // PDF URL in String format
                    "Pdf title/name ",                        // PDF Name/Title in String format
                    "",                  // If nothing specific, Put "" it will save to Downloads
                    enableDownload = true                    // This param is true by defualt.
                )
            )
        }
    }
}