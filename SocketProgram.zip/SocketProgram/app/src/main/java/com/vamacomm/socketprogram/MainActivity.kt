package com.vamacomm.socketprogram

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.StrictMode
import android.os.StrictMode.ThreadPolicy
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException


class MainActivity : AppCompatActivity() {
    lateinit var tv:TextView
    var responseText:String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val policy = ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
        tv = findViewById(R.id.tv)
        val handler = Handler()
        val runnableCode: Runnable = object : Runnable {
            override fun run() {
                Log.d("Handlers", "Called on main thread")
                callapi()
                handler.postDelayed(this, 20)
            }
        }
        handler.post(runnableCode)
    }

    private fun callapi() {
        val client = OkHttpClient()
        val request: Request = Request.Builder()
            .url("http://192.168.43.121/ask")
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) { runOnUiThread { tv.text = e.message.toString() } }
            override fun onResponse(call: Call, response: Response) { runOnUiThread { responseText = response.body!!.string();tv.text = responseText;processTask(responseText) } }
        })
    }

    private fun processTask(responseText: String) {

    }
}