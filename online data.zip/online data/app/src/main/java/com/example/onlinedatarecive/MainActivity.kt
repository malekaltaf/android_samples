package com.example.onlinedatarecive

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private val client = OkHttpClient()
    private lateinit var listView: ListView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listView = findViewById(R.id.listView)
        GlobalScope.launch(Dispatchers.IO) {
            val response = fetchResponse()
            withContext(Dispatchers.Main) {
                setResponseToListView(response)
            }
        }
    }

    private fun fetchResponse(): String {
        val request = Request.Builder()
            .url("https://anapioficeandfire.com/api/houses/1")
            .build()
        client.newCall(request).execute().use { response ->
            return response.body!!.string()
        }
    }

    private fun setResponseToListView(response: String) {
        val jsonArray = JSONArray(response)
        val jsonObject = JSONObject(response)
        val list = ArrayList<String>()
        for (i in 0 until jsonArray.length()) {
            list.add(jsonArray.getString(i))
        }
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, list)
        listView.adapter = adapter
    }
}