package com.vamacomm.playingvideofrominternalstorage

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.MediaController
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val videoPlayer = findViewById<VideoView>(R.id.videoView)
        val mediaController = MediaController(this)

        val filePath = Environment.getExternalStorageDirectory().path+"/sensor_center_zone.mp4"

        videoPlayer.setMediaController(mediaController)
        videoPlayer.setVideoURI(Uri.parse(filePath))

        if (ContextCompat.checkSelfPermission(
                this@MainActivity,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this@MainActivity,
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                1
            )
        } else {
            videoPlayer.start()
        }
    }
}
