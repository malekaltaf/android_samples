package com.example.museums

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.opengl.Visibility
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore.Video
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import android.widget.VideoView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.realpacific.clickshrinkeffect.applyClickShrink

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        // logo3 to logo30
        var logo1 = findViewById<ImageView>(R.id.logo3)
        var logo2 = findViewById<ImageView>(R.id.logo4)
        var logo3 = findViewById<ImageView>(R.id.logo5)
        var logo4 = findViewById<ImageView>(R.id.logo6)
        var logo5 = findViewById<ImageView>(R.id.logo7)
        var logo6 = findViewById<ImageView>(R.id.logo8)
        var logo7 = findViewById<ImageView>(R.id.logo9)
        var logo8 = findViewById<ImageView>(R.id.logo10)
        var logo9 = findViewById<ImageView>(R.id.logo11)
        var logo10 = findViewById<ImageView>(R.id.logo12)
        var logo11 = findViewById<ImageView>(R.id.logo13)
        var logo12 = findViewById<ImageView>(R.id.logo14)
        var logo13 = findViewById<ImageView>(R.id.logo15)
        var logo14 = findViewById<ImageView>(R.id.logo16)
        var logo15 = findViewById<ImageView>(R.id.logo17)
        var logo16 = findViewById<ImageView>(R.id.logo18)
        var logo17 = findViewById<ImageView>(R.id.logo19)
        var logo18 = findViewById<ImageView>(R.id.logo20)
        var logo19 = findViewById<ImageView>(R.id.logo21)
        var logo20 = findViewById<ImageView>(R.id.logo22)
        var logo21 = findViewById<ImageView>(R.id.logo23)
        var logo22 = findViewById<ImageView>(R.id.logo24)
        var logo23 = findViewById<ImageView>(R.id.logo25)
        var logo24 = findViewById<ImageView>(R.id.logo26)
        var logo25 = findViewById<ImageView>(R.id.logo27)
        var logo26 = findViewById<ImageView>(R.id.logo28)
        var logo27 = findViewById<ImageView>(R.id.logo29)
        var logo28 = findViewById<ImageView>(R.id.logo30)
        var logo29 = findViewById<ImageView>(R.id.logo31)
        var logo30 = findViewById<ImageView>(R.id.logo32)


        logo1.applyClickShrink()
        logo2.applyClickShrink()
        logo3.applyClickShrink()
        logo4.applyClickShrink()
        logo5.applyClickShrink()
        logo6.applyClickShrink()
        logo7.applyClickShrink()
        logo8.applyClickShrink()
        logo9.applyClickShrink()
        logo10.applyClickShrink()
        logo11.applyClickShrink()
        logo12.applyClickShrink()
        logo13.applyClickShrink()
        logo14.applyClickShrink()
        logo15.applyClickShrink()
        logo16.applyClickShrink()
        logo17.applyClickShrink()
        logo18.applyClickShrink()
        logo19.applyClickShrink()
        logo20.applyClickShrink()
        logo21.applyClickShrink()
        logo22.applyClickShrink()
        logo23.applyClickShrink()
        logo24.applyClickShrink()
        logo25.applyClickShrink()
        logo26.applyClickShrink()
        logo27.applyClickShrink()
        logo28.applyClickShrink()
        logo29.applyClickShrink()
        logo30.applyClickShrink()

        var close = findViewById<ImageView>(R.id.close_btn)

        var videoView = findViewById<VideoView>(R.id.videoView)
        if (ContextCompat.checkSelfPermission(
                this@MainActivity2,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this@MainActivity2,
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                1
            )
        } else {
//            videoPlayer.start()
        }


        videoView.setOnCompletionListener {
            videoView.stopPlayback()
            videoView.visibility = View.GONE
            close.visibility = View.GONE
        }

        close.setOnClickListener {
            Toast.makeText(this,"Video is Closed",Toast.LENGTH_LONG).show()
            videoView.visibility = View.GONE
            close.visibility = View.GONE
            videoView.stopPlayback()
        }

        logo1.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo1.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo2.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo2.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo3.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo3.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo4.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo4.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo5.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo5.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo6.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo6.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo7.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo7.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo8.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo8.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo9.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo9.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo10.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo10.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo11.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            //Toast.makeText(this,"This Video is NOT Available",Toast.LENGTH_LONG).show()
            val filePath = Environment.getExternalStorageDirectory().path+"/logo11.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo12.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo12.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo13.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo13.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo14.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo14.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo15.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo15.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo16.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo16.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo17.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo17.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo18.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo18.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo19.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo19.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo20.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo20.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo21.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo21.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo22.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo22.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo23.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo23.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo24.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo24.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo25.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo25.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo26.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo26.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo27.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo27.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }
        logo28.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo28.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
         }

        logo29.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo29.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
        }

        logo30.setOnClickListener {
            videoView.visibility = View.VISIBLE
            close.visibility = View.VISIBLE
            val filePath = Environment.getExternalStorageDirectory().path+"/logo30.mp4"
            videoView.setVideoURI(Uri.parse(filePath))
            videoView.start()
        }
    }


}
