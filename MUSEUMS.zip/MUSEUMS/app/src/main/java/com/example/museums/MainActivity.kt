package com.example.museums

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var btn1 = findViewById<ImageView>(R.id.img1)
        var btn2 = findViewById<ImageView>(R.id.img2)
        var btn3 = findViewById<ImageView>(R.id.img3)
        var btn4 = findViewById<ImageView>(R.id.img4)
        var btn5 = findViewById<ImageView>(R.id.img5)
        var btn6 = findViewById<ImageView>(R.id.img6)
        var btn7 = findViewById<ImageView>(R.id.img7)
        var btn8 = findViewById<ImageView>(R.id.img8)
        var btn9 = findViewById<ImageView>(R.id.img9)
        var btn10 = findViewById<ImageView>(R.id.img10)
        var btn11 = findViewById<ImageView>(R.id.img11)
        var btn12 = findViewById<ImageView>(R.id.img12)
        var btn13 = findViewById<ImageView>(R.id.img13)
        var btn14 = findViewById<ImageView>(R.id.img14)
        var btn15 = findViewById<ImageView>(R.id.img15)
        var btn16 = findViewById<ImageView>(R.id.img16)
        var btn17 = findViewById<ImageView>(R.id.img17)
        var btn18 = findViewById<ImageView>(R.id.img18)
        var btn19 = findViewById<ImageView>(R.id.img19)
        var btn20 = findViewById<ImageView>(R.id.img20)
        var btn21 = findViewById<ImageView>(R.id.img21)
        var btn22 = findViewById<ImageView>(R.id.img22)
        var btn23 = findViewById<ImageView>(R.id.img23)
        var btn24 = findViewById<ImageView>(R.id.img24)
        var btn25 = findViewById<ImageView>(R.id.img25)
        var btn26 = findViewById<ImageView>(R.id.img26)
        var btn27 = findViewById<ImageView>(R.id.img27)
        var btn28 = findViewById<ImageView>(R.id.img28)

    }
}