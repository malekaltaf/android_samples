package com.vamacomm.playingspinds

import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.ceil

var MusicArray = arrayOf(R.raw.tech_house_vibes,R.raw.games,R.raw.feeling)
var musicString = arrayOf("Tech House Vibes","Games","Feeling")
var isPlaying = false
var i = 0
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var text = findViewById<TextView>(R.id.music)

        text.setText(musicString[i])

        var seekBar = findViewById<SeekBar>(R.id.seekBar)

        var MP = MediaPlayer.create(this,R.raw.games)
        MP.start()

        var maxPos = MP.duration
        var currentPos = MP.currentPosition

        while (currentPos < maxPos){

        }

    }
}





//
//        if (max != null) {
//            seekBar.max = max
//        }
//        if (currentPos != null) {
//            seekBar.progress = currentPos
//        }

//        if (currentPos != null) {
//            while (mMediaPlayer!=null && mMediaPlayer!!.isPlaying && currentPos is <= max!!){
//                Thread.sleep(500)
//                currentPos = mMediaPlayer!!.currentPosition
//                seekBar.progress = currentPos
//            }

//                next.setOnClickListener {
//
//                    if(isPlaying){
//                        mMediaPlayer!!.stop()
//                        mMediaPlayer!!.release()
//                        mMediaPlayer = null
//                        isPlaying=false
//                    }else{
//                        isPlaying=false
//                    }
//
//
//                    if(i<2){
//                        i++
//                        text.setText(musicString[i])
//                    }else{
//                        i=0
//                        text.setText(musicString[i])
//                    }
//
//                }



//        play.setOnClickListener {
//            if(!isPlaying){
//                mMediaPlayer = MediaPlayer.create(this, MusicArray[i])
//                mMediaPlayer!!.isLooping = true
//                mMediaPlayer!!.start()
//                isPlaying=true
//            }else{
//                Toast.makeText(this,"Song is already playing!!!",Toast.LENGTH_LONG).show()
//            }
//
//        }

//        pause.setOnClickListener {
//            if(isPlaying){
//                mMediaPlayer!!.stop()
//                mMediaPlayer!!.release()
//                mMediaPlayer = null
//                isPlaying=false
//            }else{
//                isPlaying=false
//            }
//
//        }

