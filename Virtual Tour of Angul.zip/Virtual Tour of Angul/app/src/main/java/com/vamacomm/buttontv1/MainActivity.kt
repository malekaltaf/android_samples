package com.vamacomm.buttontv1

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.view.KeyEvent
import android.widget.VideoView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    //val videoArrays = arrayOf(null,"/01.mp4","/02.mp4","/03.mp4","/04.mp4","/05.mp4")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val videoPlayer = findViewById<VideoView>(R.id.videoView)
//        val filePath = Environment.getExternalStorageDirectory().path+"/01.mp4"
//        videoPlayer.setVideoURI(Uri.parse(filePath))
        if (ContextCompat.checkSelfPermission(
                this@MainActivity,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this@MainActivity,
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                1
            )
        } else {
            videoPlayer.start()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val videoPlayer = findViewById<VideoView>(R.id.videoView)
        when(keyCode){
            KeyEvent.KEYCODE_A -> {
                //Toast.makeText(this,"A Hindi 1",Toast.LENGTH_SHORT).show()
                val filePath = Environment.getExternalStorageDirectory().path+"/GeoHin.mp4"
                videoPlayer.setVideoURI(Uri.parse(filePath))
                videoPlayer.start()
            }
            KeyEvent.KEYCODE_B ->{
                //Toast.makeText(this,"B English 1",Toast.LENGTH_SHORT).show()
                val filePath = Environment.getExternalStorageDirectory().path+"/GeoEng.mp4"
                videoPlayer.setVideoURI(Uri.parse(filePath))
                videoPlayer.start()
            }
            KeyEvent.KEYCODE_C ->{
                //Toast.makeText(this,"C Hindi 2",Toast.LENGTH_SHORT).show()
                val filePath = Environment.getExternalStorageDirectory().path+"/ResHin.mp4"
                videoPlayer.setVideoURI(Uri.parse(filePath))
                videoPlayer.start()
            }
            KeyEvent.KEYCODE_D ->{
                //Toast.makeText(this,"D English 2",Toast.LENGTH_SHORT).show()
                val filePath = Environment.getExternalStorageDirectory().path+"/ResEng.mp4"
                videoPlayer.setVideoURI(Uri.parse(filePath))
                videoPlayer.start()
            }
            KeyEvent.KEYCODE_E ->{
                //Toast.makeText(this,"E Hindi 3",Toast.LENGTH_SHORT).show()
                val filePath = Environment.getExternalStorageDirectory().path+"/IndHin.mp4"
                videoPlayer.setVideoURI(Uri.parse(filePath))
                videoPlayer.start()
            }
            KeyEvent.KEYCODE_F ->{
                //Toast.makeText(this,"F English 3",Toast.LENGTH_SHORT).show()
                val filePath = Environment.getExternalStorageDirectory().path+"/IndEng.mp4"
                videoPlayer.setVideoURI(Uri.parse(filePath))
                videoPlayer.start()
            }
            KeyEvent.KEYCODE_G ->{
                //Toast.makeText(this,"G Hindi 4",Toast.LENGTH_SHORT).show()
                val filePath = Environment.getExternalStorageDirectory().path+"/ArtHin.mp4"
                videoPlayer.setVideoURI(Uri.parse(filePath))
                videoPlayer.start()
            }
            KeyEvent.KEYCODE_H ->{
                //Toast.makeText(this,"H English 4",Toast.LENGTH_SHORT).show()
                val filePath = Environment.getExternalStorageDirectory().path+"/ArtEng.mp4"
                videoPlayer.setVideoURI(Uri.parse(filePath))
                videoPlayer.start()
            }
            KeyEvent.KEYCODE_I ->{
                //Toast.makeText(this,"I Hindi 5",Toast.LENGTH_SHORT).show()
                val filePath = Environment.getExternalStorageDirectory().path+"/CulHin.mp4"
                videoPlayer.setVideoURI(Uri.parse(filePath))
                videoPlayer.start()
            }
            KeyEvent.KEYCODE_J ->{
                //Toast.makeText(this,"J English 5",Toast.LENGTH_SHORT).show()
                val filePath = Environment.getExternalStorageDirectory().path+"/CulEng.mp4"
                videoPlayer.setVideoURI(Uri.parse(filePath))
                videoPlayer.start()
            }
            KeyEvent.KEYCODE_1 ->{
                //Toast.makeText(this,"1 Odia Geo",Toast.LENGTH_SHORT).show()
                val filePath = Environment.getExternalStorageDirectory().path+"/GeoOdi.mp4"
                videoPlayer.setVideoURI(Uri.parse(filePath))
                videoPlayer.start()
            }
            KeyEvent.KEYCODE_2 ->{
                //Toast.makeText(this,"2 Odia Res",Toast.LENGTH_SHORT).show()
                val filePath = Environment.getExternalStorageDirectory().path+"/ResOdi.mp4"
                videoPlayer.setVideoURI(Uri.parse(filePath))
                videoPlayer.start()
            }
            KeyEvent.KEYCODE_3 ->{
               // Toast.makeText(this,"3 Odia Ind",Toast.LENGTH_SHORT).show()
                val filePath = Environment.getExternalStorageDirectory().path+"/IndOdi.mp4"
                videoPlayer.setVideoURI(Uri.parse(filePath))
                videoPlayer.start()
            }
            KeyEvent.KEYCODE_4 ->{
                //Toast.makeText(this,"4 Odia Art",Toast.LENGTH_SHORT).show()
                val filePath = Environment.getExternalStorageDirectory().path+"/ArtOdi.mp4"
                videoPlayer.setVideoURI(Uri.parse(filePath))
                videoPlayer.start()
            }
            KeyEvent.KEYCODE_5 ->{
                //Toast.makeText(this,"5 Odia Cul",Toast.LENGTH_SHORT).show()
                val filePath = Environment.getExternalStorageDirectory().path+"/CulOdi.mp4"
                videoPlayer.setVideoURI(Uri.parse(filePath))
                videoPlayer.start()
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}