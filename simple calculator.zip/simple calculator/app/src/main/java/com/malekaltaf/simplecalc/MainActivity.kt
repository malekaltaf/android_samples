package com.malekaltaf.simplecalc

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.malekaltaf.simplecalc.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPlus.setOnClickListener {
            if(binding.et1.text.isEmpty() || binding.et2.text.isEmpty()){
                binding.et1.error = "This Field Can not be Empty!"
                binding.et2.error = "This Field Can not be Empty!"
            }else{
                binding.tvAns.text = (Integer.parseInt(binding.et1.text.toString()) + Integer.parseInt(binding.et2.text.toString())).toString()
            }
        }

        binding.btnMinus.setOnClickListener {
            if(binding.et1.text.isEmpty() || binding.et2.text.isEmpty()){
                binding.et1.error = "This Field Can not be Empty!"
                binding.et2.error = "This Field Can not be Empty!"
            }else{
                binding.tvAns.text = (Integer.parseInt(binding.et1.text.toString()) - Integer.parseInt(binding.et2.text.toString())).toString()
            }
        }

        binding.btnMul.setOnClickListener {
            if(binding.et1.text.isEmpty() || binding.et2.text.isEmpty()){
                binding.et1.error = "This Field Can not be Empty!"
                binding.et2.error = "This Field Can not be Empty!"
            }else{
                binding.tvAns.text = (Integer.parseInt(binding.et1.text.toString()) * Integer.parseInt(binding.et2.text.toString())).toString()
            }
        }

        binding.btnDiv.setOnClickListener {
            if(binding.et1.text.isEmpty() || binding.et2.text.isEmpty()){
                binding.et1.error = "This Field Can not be Empty!"
                binding.et2.error = "This Field Can not be Empty!" }
            else{
                binding.tvAns.text = (Integer.parseInt(binding.et1.text.toString()) / Integer.parseInt(binding.et2.text.toString())).toString()
            }
        }

    }
}